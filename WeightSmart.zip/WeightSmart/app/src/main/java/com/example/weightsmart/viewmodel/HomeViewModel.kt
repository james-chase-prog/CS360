package com.example.weightsmart.viewmodel

class HomeViewModel {
}