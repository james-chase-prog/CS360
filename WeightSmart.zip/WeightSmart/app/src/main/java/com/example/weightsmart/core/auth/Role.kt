package com.example.weightsmart.core.auth

/** High-level roles in the app. */
enum class Role {
    USER,   // normal app usage (manage own data)
    ADMIN   // full access
}
