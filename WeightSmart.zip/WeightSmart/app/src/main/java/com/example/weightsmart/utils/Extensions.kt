package com.example.weightsmart.utils

class Extensions {
}